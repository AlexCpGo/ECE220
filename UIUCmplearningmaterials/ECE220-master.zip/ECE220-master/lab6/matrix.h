void matrix_multiply(double *matrixA,double *matrixB,double *matrixC,
                    int m,int k,int n);
