#ifndef SLIDING_H
#define SLIDING_H
void slide_up(int* my_array, int rows, int cols);

#endif
