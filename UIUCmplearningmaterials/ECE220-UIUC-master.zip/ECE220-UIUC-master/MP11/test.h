#include "floorplan.h"

#ifndef TEST_H_
#define TEST_H_

// Testing procedure.
int test(const char []);



#endif
