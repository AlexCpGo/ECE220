void updateBoard_gold(int* board, int boardRowSize, int boardColSize);
int countLiveNeighbor_gold(int* board, int boardRowSize, int boardColSize, int row, int col);
int aliveStable_gold(int* board, int boardRowSize, int boardColSize);
